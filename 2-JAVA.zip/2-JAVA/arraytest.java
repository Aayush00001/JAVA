class arraytest
{
	public static void main[String args[]]
	{
		int a[]={4,7,8};
		System.ou.println("lenth of array is:"+a.lenth);
	}
}
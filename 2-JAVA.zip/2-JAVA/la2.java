//2. Write a Java Program to input Unit from the user and //calculate Bill.
//Unit charges per unit
//0-100 5.2
//101-200 5.9
//201-400 6.7
//401-600 7.2
//601-~ 7.6

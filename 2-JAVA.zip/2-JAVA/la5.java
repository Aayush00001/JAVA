//Define a class Student having data members rollno, name and age.Define getData() andputData() method to initialize and 
//display value of data members.

class Myapplet extends Applet
{
    public void init()
    {
        add(lab);
        add(but);
        add(toggle);
        add(txt);
    }
}
class A1
{
	public static void main(String[] args)
	{
		int num=8;
		if(num%2==0)
		{
			System.out.println("even");
		}
		else
		{
			System.out.println("odd");
		}
	}

}
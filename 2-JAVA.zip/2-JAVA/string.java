//string method
class String
{
    private static String concat;

    public static void main(String args[])
    {
        //Returns length of the string
        String str="Rajkot";
        int i=str.length();
        System.out.println(i);

        concat
        String s="Rajkot";
        concat=s.concat("gujarat");
        System.out.println(concat);

        //charat
        str="atmiya";
        char d=str.charAt[2];
        System.out.println(d);
        
    }
}


class abc
{
	public static void main(String[] args)
	{
		int a=10;
		int b=20;
		System.out.println("addition is:-->"+(a+b));
		System.out.println("sub. is:-->"+(a-b));
		System.out.println("mul. is:-->"+(a*b));
		System.out.println("divi. is:-->"+(a/b));
	}
}
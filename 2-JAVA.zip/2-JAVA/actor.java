//ex with this keyword
class actor 
{
	String lastname;
	String Firstname;
	actor(String lastname,String firstname)
	{
		this.lastname=lastname;
		this.firstname=firstname;
	}
public static void(string args[])
{
	actor=new actor("devgan","ajay");
	System.out.println("name of actor."+a.firstname" "+a.lastname);
}
}
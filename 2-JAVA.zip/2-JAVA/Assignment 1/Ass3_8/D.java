public class D 
{ 
    public static void main(String[] args) {
		String str = "Hello ..Hi..";
		String newStr = str.replace('H', 'n');
		
		System.out.println("Original String: "+str);
		System.out.println("New String: "+newStr);
	}
}

public class C 
{ 
    public static void main(String[] args) {
        
        String str = "Enjoy Holiday";
        String strUpper = str.toUpperCase();
        
        System.out.println("Original String: " + str);
        System.out.println("String in Uppercase: " + strUpper);
    }
    
}


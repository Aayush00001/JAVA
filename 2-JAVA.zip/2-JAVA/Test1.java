//static import maths methoad
import static java.lang.System.*;
import static java.lang.Math.*;
class Test1
{
    public static void main(String[] args)
    {
    out.println(sqrt(4));//2.0
    out.println(pow(2, 2));//4.0
    out.println(abs(6.3));//6.3
    out.println(PI); // 3.141592653589793
    out.println(E); // 2.718281828459045
    out.println(pow(2, 3)); // 8.0
    out.println(exp(1)); // 2.718281828459045
    out.println(log10(10)); // 1.0
    out.println(sqrt(64)); // 8.0
    out.println(cbrt(64)); // 4.0
    out.println(abs(-20)); // 20
    out.println(max(10, -20)); // 10
    out.println(min(10, -20)); // -20
    }
}
import java.util.Scanner;
class Ass_8
{
		public static void main(String[] args)
		{
			int num=Integer.parseInt(args[0]);
			System.out.println("Value is:->>");
			for(int i=0;i<args.length;i++)
			{
				System.out.println(args[i]);
			}
		}
}
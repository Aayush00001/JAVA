//string method
class String1
{
    public static void main(String args[])
    {
        //Returns length of the string
        //String str="Rajkot";
        // i=str.length();
        //System.out.println(i);

        //concat
        //String s="Rajkot";
        //s.concat("gujarat");
        //System.out.println(s.concat("gujarat"));

        //charat
        // d=str.charAt(2);
        //.out.println(d);   

        //two steing
       // String st=new String("atmiya");
        //int ans=st.compareTo("atmiya");
        //System.out.println(ans);
        
        //char from this stirng
        Byte[] b=new Byte[10];
        String sr="rajkot";
        b=sr.getBytes();

        //convert the string
        String sa="Atmiya";
        char c=new char[10];
        c=S.ToChararray();
    }
}


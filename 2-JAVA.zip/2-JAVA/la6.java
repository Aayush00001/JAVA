//Write a Java Program to given discount on above program.Bill Amount Discount
//<500 30%
//>500 - <1000 20%
//>1000 - ~ 15%
//Maximum discount Rs. 500

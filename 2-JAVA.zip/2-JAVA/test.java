//refer array using for loop
public class test
{
	public static void main(String args[])
	{
		int[] number={10,20,30,40,50};
		for(int x=numbers)
		{
			System.out.print(x+",");
		}
			System.out.println();
			String[]names={"aayush","ayush","aayushi","aayu"};
			for(String names:names)
		{
			System.out.print(names+",");
		}
	}
}
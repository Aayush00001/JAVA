class Ass_2
{
	public static void main(String[] args)
	{
	int length=20;
	int width=30;
	int a=length*width;
	System.out.print("Area of ractangle"+a);
	}
}
	
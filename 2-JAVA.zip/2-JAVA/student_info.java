//ex of class and object
class student_info
{
	int id;
	String name;
	public static void main(String args[])
	{
		student_info s=new student_info();
		s.id=1;
		s.name="atmiya";
		System.out.println(s.id);
		Systeam.out.prinln(s.name);
	}
}
//Method overloading by changing data type of parameters int sub( int x, int y) double sub(double x, double y)

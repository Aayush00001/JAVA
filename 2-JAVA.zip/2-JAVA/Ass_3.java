class Ass_3
{
		public static void main(String[] args)
		{
			int a=80;
			int b=40;
			int c=10;
			if(a<b)
			{
				if(a<c)
				{
					System.out.println("a is minimum"+a);
				}
				
			}
			else if(b<c)
				{
					System.out.println("b is minimum"+b);
				}
		    else
			{
				System.out.println("c is minimum"+c);
			}
	    }
}

				
			
				